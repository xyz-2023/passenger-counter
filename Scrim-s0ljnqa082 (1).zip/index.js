let saveEl = document.getElementById("save-el")
let countEl = document.getElementById("count-el")
let count = 0
let msgEl = document.getElementbyId("msg")

function increment() {
    count += 1
    countEl.textContent = count
}

function decrement() {
    if(count > 0 ){
        count -= 1
    }
    else if(count == 0){
        //bug here
        countEl.textContent = " Error! Can't decrement below 0 !! "
        console.log( " Error! Can't decrement below 0 !! ")
    }
    countEl.textContent = count
}

function save() {
    let countStr = count + " - "
    saveEl.textContent += countStr
    countEl.textContent = 0
    count = 0
}
